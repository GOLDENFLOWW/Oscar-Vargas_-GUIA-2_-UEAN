package mundo;
import java.util.Random;

public class Alcancia {
    // -----------------------------------------------------------------
    // Atributos
    // -----------------------------------------------------------------

    /**
     * N�mero de monedas de $50 que hay en la alcanc�a.
     */
    private int numeroMonedas50;

    /**
     * N�mero de monedas de $100 que hay en la alcanc�a.
     */
    private int numeroMonedas100;

    /**
     * N�mero de monedas de $200 que hay en la alcanc�a.
     */
    private int numeroMonedas200;

    /**
     * N�mero de monedas de $500 que hay en la alcanc�a.
     */
    private int numeroMonedas500;

    /**
     * N�mero de monedas de $1000 que hay en la alcanc�a.
     */
    private int numeroMonedas1000;

    /**
     * Estado de la alcanc�a. <br>
     * 0 indica que no est� rota. <br>
     * 1 indica que est� rota.
     */
    private int estado;

    // -----------------------------------------------------------------
    // M�todos
    // -----------------------------------------------------------------

    /**
     * Construye la alcanc�a. <br>
     * <b>post: </b> El n�mero de monedas de 50, n�mero de monedas de 100, n�mero de monedas de 200, n�mero de monedas de 500, n�mero de monedas de 1000 <br>
     * y el estado fueron inicializados en 0.
     */
    public Alcancia() {
        numeroMonedas50 = 0;
        numeroMonedas100 = 0;
        numeroMonedas200 = 0;
        numeroMonedas500 = 0;
        numeroMonedas1000 = 0;
        estado = 0;
    }

    /**
     * Retorna el n�mero de monedas de $50 que hay en la alcanc�a.
     *
     * @return N�mero de monedas de $50 en la alcanc�a.
     */
    public int darNumeroMonedas50() {
        return numeroMonedas50;
        
    }

    /**
     * Retorna el n�mero de monedas de $100 que hay en la alcanc�a.
     *
     * @return N�mero de monedas de $100 en la alcanc�a.
     */
    public int darNumeroMonedas100() {
        return numeroMonedas100;
        
    }

    /**
     * Retorna el n�mero de monedas de $200 que hay en la alcanc�a.
     *
     * @return N�mero de monedas de $200 en la alcanc�a.
     */
    public int darNumeroMonedas200() {
        return numeroMonedas200;
    }

    /**
     * Retorna el n�mero de monedas de $500 que hay en la alcanc�a.
     *
     * @return N�mero de monedas de $500 en la alcanc�a.
     */
    public int darNumeroMonedas500() {
        return numeroMonedas500;
    }

    /**
     * Retorna el n�mero de monedas de $1000 que hay en la alcanc�a.
     *
     * @return N�mero de monedas de $1000 en la alcanc�a.
     */
    public int darNumeroMonedas1000() {
        return numeroMonedas1000;
    }

    /**
     * Informa si la alcanc�a est� rota o no.
     *
     * @return Retorna "ROTA" si est� rota, "NO ROTA" en caso contrario.
     */
    public String darEstado() {
        return (estado == 1) ? "ROTA" : "NO ROTA";
    }

    /**
     * Retorna el total de dinero que hay en la alcanc�a.
     *
     * @return Total de dinero que hay en la alcanc�a.
     */
    public int calcularTotalDinero() {
        int total = 0;
        total += numeroMonedas50 * 50;
        total += numeroMonedas100 * 100;
        total += numeroMonedas200 * 200;
        total += numeroMonedas500 * 500;
        total += numeroMonedas1000 * 1000;
        return total;
    }

    /**
     * Retorna el estado de la alcanc�a. <br>
     * <b>pre: </b> La alcanc�a no est� rota.
     *
     * @return Cadena que informa la cantidad de monedas que hab�a en la alcanc�a y la cantidad total de dinero.
     */
    public String darEstadoAlcancia() {
        int totalDinero = calcularTotalDinero();

        return "La alcanc�a ten�a: \n " + numeroMonedas50 + " moneda(s) de $50 \n " + numeroMonedas100 + " moneda(s) de $100 \n " + numeroMonedas200 + " moneda(s) de $200 \n " + numeroMonedas500 + " moneda(s) de $500 \n " + numeroMonedas1000
                + " moneda(s) de $1000 \n " + "Para un total de $" + totalDinero + " pesos.";
    }

    /**
     * Agrega una moneda de $50 a la alcanc�a. <br>
     * <b>pre: </b> La alcanc�a no est� rota. <br>
     * <b>post: </b> Aument� en uno la cantidad de monedas de $50 en la alcanc�a.
     */
    public void agregarMoneda50(){
        if (estado == 0) { // Verificar si la alcancía no está rota
            numeroMonedas50++;
        } 
    }

    
    public void agregarMoneda100(){
        if (estado == 0) { // Verificar si la alcancía no está rota
            numeroMonedas100++;
        } 
    } 

    public void agregarMoneda200(){
        if (estado == 0) { // Verificar si la alcancía no está rota
            numeroMonedas200++;
        } 
    } 

    public void agregarMoneda500(){
        if (estado == 0) { // Verificar si la alcancía no está rota
            numeroMonedas500++;
        } 
    } 

    
    public void agregarMoneda1000(){
        if (estado == 0) { // Verificar si la alcancía no está rota
            numeroMonedas1000++;
        } 
    }

    /**
     * Rompe la alcanc�a. Es decir, cambia el estado a 1<br>
     */
    public void romperAlcancia() {
        estado = 1; // Cambiar el estado a "rota"
    }

    // -----------------------------------------------------------------
    // Puntos de Extensi�n
    // -----------------------------------------------------------------

    /**
     * De las 5 denominaciones de monedas que hay en la alcanc�a (de 50, de 100,
     * de 200, de 500 y de 1000), retorna cu�l tiene la mayor cantidad de monedas.
     *
     * @return la denominaci�n m�s numerosa en la alcanc�a: 50 o 100 o 200 o 500 o 1000.
     */
    public int obtenerDenominacionMasNumerosa() {
        int[] cantidades = {numeroMonedas50, numeroMonedas100, numeroMonedas200, numeroMonedas500, numeroMonedas1000};
        int denominacionMasNumerosa = 50;
        int mayorCantidad = cantidades[0];

        for (int i = 1; i < cantidades.length; i++) {
            if (cantidades[i] > mayorCantidad) {
                mayorCantidad = cantidades[i];
                denominacionMasNumerosa = (i + 1) * 50; // Calcular la denominación correspondiente
            }
        }

        return denominacionMasNumerosa;
    }

    /**
     * Una alcanc�a es valiosa si solo posee monedas de 1000 y de 500, y no hay
     * monedas de otras denominaciones.
     *
     * Este m�todo permite determinar si la alcanc�a es valiosa, o sea, solo posee
     * monedas de 1000 pesos y de 500
     *
     * @return si es valiosa o no
     */
    public boolean valiosa() {
        return (numeroMonedas50 == 0 && numeroMonedas100 == 0 && numeroMonedas200 == 0 
                && numeroMonedas500 > 0 && numeroMonedas1000 > 0);
    }

    // Método para llenar la alcancía con 1000 monedas aleatorias (Requisito R1)
    public void llenarAlcancia() {
        Random random = new Random();
        for (int i = 0; i < 1000; i++) {
            int denominacion = random.nextInt(5); // Genera un número aleatorio entre 0 y 4
            switch (denominacion) {
                case 0:
                    agregarMoneda50();
                    break;
                case 1:
                    agregarMoneda100();
                    break;
                case 2:
                    agregarMoneda200();
                    break;
                case 3:
                    agregarMoneda500();
                    break;
                case 4:
                    agregarMoneda1000();
                    break;
            }
        }
    }

    // Método para mostrar la información del llenado (Requisitos R2 y R3)
    public void mostrarInformacionLlenado() {
        System.out.println("Cantidad de monedas de $50: " + darNumeroMonedas50());
        System.out.println("Cantidad de monedas de $100: " + darNumeroMonedas100());
        System.out.println("Cantidad de monedas de $200: " + darNumeroMonedas200());
        System.out.println("Cantidad de monedas de $500: " + darNumeroMonedas500());
        System.out.println("Cantidad de monedas de $1000: " + darNumeroMonedas1000());

        System.out.println("Total ahorrado en monedas de $50: $" + darNumeroMonedas50() * 50);
        System.out.println("Total ahorrado en monedas de $100: $" + darNumeroMonedas100() * 100);
        System.out.println("Total ahorrado en monedas de $200: $" + darNumeroMonedas200() * 200);
        System.out.println("Total ahorrado en monedas de $500: $" + darNumeroMonedas500() * 500);
        System.out.println("Total ahorrado en monedas de $1000: $" + darNumeroMonedas1000() * 1000);

        System.out.println("Total ahorrado en la alcancía: $" + calcularTotalDinero()); 
    }
}
